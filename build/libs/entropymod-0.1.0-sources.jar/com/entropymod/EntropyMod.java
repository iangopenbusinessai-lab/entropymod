package com.entropymod;

import com.entropymod.command.EntropyCommands;
import com.entropymod.entropy.EffectBehaviors;
import com.entropymod.entropy.EntropyManager;
import com.entropymod.network.ChoiceMadePayload;
import com.entropymod.network.HistoryRequestPayload;
import com.entropymod.network.HistoryResponsePayload;
import com.entropymod.network.OpenChoicePayload;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityLevelChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EntropyMod implements ModInitializer {
	public static final String MOD_ID = "entropymod";

	// This logger is used to write text to the console and the log file.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Entropy Mod initializing...");

		// Register both payload types so they can be sent/received at all.
		// NOTE: clientboundPlay()/serverboundPlay() -- these were playS2C()/playC2S()
		// in older Fabric API versions; renamed at some point. Verified against
		// current docs.fabricmc.net/develop/networking.
		PayloadTypeRegistry.clientboundPlay().register(OpenChoicePayload.TYPE, OpenChoicePayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(ChoiceMadePayload.TYPE, ChoiceMadePayload.CODEC);
		PayloadTypeRegistry.serverboundPlay().register(HistoryRequestPayload.TYPE, HistoryRequestPayload.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(HistoryResponsePayload.TYPE, HistoryResponsePayload.CODEC);

		// Effect ids are matched between EffectRegistry and EffectBehaviors by string,
		// which the compiler cannot check. Report mismatches once, at startup.
		EffectBehaviors.validate();

		// When a player submits their pick, hand it to that player's EntropyManager.
		// Per Fabric docs, this handler already runs on the server thread, so no
		// extra .execute() hop is needed (unlike older Fabric API versions).
		// player.level() + cast to ServerLevel is the pattern shown directly in
		// docs.fabricmc.net/develop/networking (both context.player().level()
		// and the (ServerLevel) cast appear there, just not combined this way).
		ServerPlayNetworking.registerGlobalReceiver(ChoiceMadePayload.TYPE, (payload, context) -> {
			MinecraftServer server = ((ServerLevel) context.player().level()).getServer();
			EntropyManager.get(server).onChoiceMade(server, payload.chosenEffectId());
		});

		// History is fetched on demand, and answered only to the player who asked --
		// this is a read, so it never touches the loop's state.
		ServerPlayNetworking.registerGlobalReceiver(HistoryRequestPayload.TYPE, (payload, context) -> {
			MinecraftServer server = ((ServerLevel) context.player().level()).getServer();
			var history = EntropyManager.get(server).getHistory();
			LOGGER.info("History requested by {} -- {} pick(s).", context.player().getName().getString(), history.size());
			ServerPlayNetworking.send(context.player(), HistoryResponsePayload.from(history));
		});

		// Server-side debug commands (/entropyforcepick, /entropystatus). These talk
		// to the real EntropyManager, unlike the client-side /entropypreview.
		EntropyCommands.register();

		// ---- Effect re-application ----------------------------------------
		// All effects are permanent, but the state that implements them is NOT.
		// Attribute modifiers are applied transiently (never written to player NBT
		// -- see AttributeEffectBehavior for why), and on top of that a death
		// respawn builds a brand-new ServerPlayer whose attribute map starts empty:
		// vanilla's restoreFrom only carries permanent modifiers, and only when its
		// boolean parameter is true, which it is not for a death. Verified in
		// bytecode, see CLAUDE.md.
		//
		// So these three hooks are not a safety net -- they are the only thing that
		// puts effects back. Every apply() is required to be idempotent, so
		// re-applying an effect the player still has is a no-op rather than a
		// double-stack.
		// NOTE: there is no Entity.getServer() in this mapping. ServerPlayer.level()
		// returns ServerLevel covariantly, so level().getServer() is the accessor --
		// see the CLAUDE.md mapping note.
		ServerPlayerEvents.JOIN.register(EntropyMod::reapplyTo);

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> reapplyTo(newPlayer));

		// Returning from the End goes through PlayerList.respawn too, but an
		// ordinary portal does not -- it moves the same entity between levels. This
		// covers that path so a trip to the Nether can't quietly drop everything.
		ServerEntityLevelChangeEvents.AFTER_PLAYER_CHANGE_LEVEL.register(
				(player, origin, destination) -> reapplyTo(player));

		// Every server tick, let the EntropyManager check whether it's time
		// for the next pick. This is the heartbeat of the whole mod.
		ServerTickEvents.END_SERVER_TICK.register(server -> {
			EntropyManager.get(server).tick(server);
		});

		LOGGER.info("Entropy Mod ready. Default interval: {} ticks ({} min), cap: {}",
				EntropyManager.DEFAULT_INTERVAL_TICKS,
				EntropyManager.DEFAULT_INTERVAL_TICKS / 1200.0,
				EntropyManager.DEFAULT_ENTROPY_CAP);
	}

	/** Re-establishes every acquired effect on one player. See the registrations above. */
	private static void reapplyTo(ServerPlayer player) {
		MinecraftServer server = player.level().getServer();
		if (server == null) {
			return;
		}
		EntropyManager.get(server).reapplyAll(server, player);
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
